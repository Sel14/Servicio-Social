package com.example.data

data class Units(
    val unitId: Int,
    val name:String,
    val category: String,
    val description: String
)
